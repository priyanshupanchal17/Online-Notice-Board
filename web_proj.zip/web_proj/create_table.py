import sqlite3

conn = sqlite3.connect('database.db')
print("Connected to database successfully")

# Create the "events" table
conn.execute('''
CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY,
    name TEXT,
    venue TEXT,
    details TEXT,
    date TEXT,
    participants TEXT
)
''')

print("Created the 'events' table successfully!")

conn.close()
