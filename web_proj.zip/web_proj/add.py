import sqlite3

conn = sqlite3.connect('database.db')
print("Connected to database successfully")

# Remove the "events" table
conn.execute('DROP TABLE IF EXISTS events')

print("Removed table successfully!")

conn.close()
